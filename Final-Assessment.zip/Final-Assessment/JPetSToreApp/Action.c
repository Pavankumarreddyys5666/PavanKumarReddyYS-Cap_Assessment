Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

/*Correlation comment - Do not change!  Original value='FISH' Name ='p_category' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=p_category",
		"RegExp=categories/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790836606237\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_concurrent_start(NULL);

	web_url("logo-topbar.gif", 
		"URL=https://jpetstore.aspectran.com/images/logo-topbar.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("splash.gif", 
		"URL=https://jpetstore.aspectran.com/images/splash.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(51);

	lr_start_transaction("1_LaunchURL");

	lr_end_transaction("1_LaunchURL",LR_AUTO);

	lr_start_transaction("2_Category");

/*Correlation comment - Do not change!  Original value='FI-SW-01' Name ='p_productid' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=p_productid",
		"RegExp=products/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("Fish",
		"URL=https://jpetstore.aspectran.com/categories/{p_category}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/",
		"Snapshot=t4.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("2_Category",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("3_productid");

/*Correlation comment - Do not change!  Original value='EST-1' Name ='p_itemiditemId' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=p_itemiditemId",
		"RegExp=items/(.*?)\">EST-1",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("FI-SW-01",
		"URL=https://jpetstore.aspectran.com/products/{p_productid}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/categories/{p_category}",
		"Snapshot=t5.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("3_productid",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("4_itemid");

	web_url("EST-1",
		"URL=https://jpetstore.aspectran.com/products/{p_productid}/items/{p_itemiditemId}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{p_productid}",
		"Snapshot=t6.inf",
		"Mode=HTTP",
		LAST);

	web_url("fish1.jpg",
		"URL=https://jpetstore.aspectran.com/images/fish1.jpg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://jpetstore.aspectran.com/products/{p_productid}/items/{p_itemiditemId}",
		"Snapshot=t7.inf",
		LAST);

	lr_end_transaction("4_itemid",LR_AUTO);

	lr_start_transaction("5_addtocart");

	web_url("Add to Cart",
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId={p_itemiditemId}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{p_productid}/items/{p_itemiditemId}",
		"Snapshot=t8.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("5_addtocart",LR_AUTO);

	lr_start_transaction("6_proceedtocheckout");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t9.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("6_proceedtocheckout",LR_AUTO);

	lr_start_transaction("7_Login");

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm?referer=/order/newOrderForm", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=referer", "Value=/order/newOrderForm", ENDITEM, 
		"Name=username", "Value={username}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		LAST);

	web_url("banner_dogs.gif", 
		"URL=https://jpetstore.aspectran.com/images/banner_dogs.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t11.inf", 
		LAST);

	lr_end_transaction("7_Login",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("8_continue");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t12.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value=999999999999999", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=Test", ENDITEM, 
		"Name=billToLastName", "Value=User", ENDITEM, 
		"Name=billAddress1", "Value=123 Test St", ENDITEM, 
		"Name=billAddress2", "Value=123 Test St", ENDITEM, 
		"Name=billCity", "Value=Testville", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value=10001", ENDITEM, 
		"Name=billCountry", "Value=US", ENDITEM, 
		LAST);

	lr_end_transaction("8_continue",LR_AUTO);

	lr_start_transaction("9_confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("9_confirm",LR_AUTO);

	return 0;
}