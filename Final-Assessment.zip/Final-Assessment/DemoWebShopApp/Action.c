Action()
{
    web_set_sockets_option("SSL_VERSION", "AUTO");

    web_set_max_html_param_len("4096");

    web_add_auto_header(
        "Accept-Language",
        "en-IN,en-US;q=0.9,en;q=0.8");

    web_url("demowebshop.tricentis.com",
        "URL=https://demowebshop.tricentis.com/",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=",
        "Mode=HTTP",
        LAST);

    lr_think_time(3);

    lr_start_transaction("1_login");

    web_url("Log in",
        "URL=https://demowebshop.tricentis.com/login",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/",
        "Mode=HTTP",
        LAST);


    web_submit_data("login",
        "Action=https://demowebshop.tricentis.com/login",
        "Method=POST",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/login",
        "Mode=HTTP",
        "EncodeAtSign=YES",
        ITEMDATA,

        "Name=Email",
        "Value={Email}",
        ENDITEM,

        "Name=Password",
        "Value={Password}",
        ENDITEM,

        "Name=RememberMe",
        "Value=false",
        ENDITEM,

        LAST);


    lr_end_transaction("1_login", LR_AUTO);

    lr_think_time(5);

    lr_start_transaction("2_search");


    web_url("searchtermautocomplete",
        "URL=https://demowebshop.tricentis.com/catalog/searchtermautocomplete?term={SearchTerm}",
        "Resource=0",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/",
        "Mode=HTTP",
        LAST);


    web_url("search",
        "URL=https://demowebshop.tricentis.com/search?q={SearchTerm}",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/",
        "Mode=HTTP",
        LAST);


    lr_end_transaction("2_search", LR_AUTO);

    lr_think_time(5);

    lr_start_transaction("3_itemclick");


    web_url("Build your own cheap computer",
        "URL=https://demowebshop.tricentis.com/build-your-cheap-own-computer",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/search?q={SearchTerm}",
        "Mode=HTTP",
        LAST);


    lr_end_transaction("3_itemclick", LR_AUTO);

    lr_think_time(5);

    lr_start_transaction("4_addtocart");


    web_submit_data("AddToCart",
        "Action=https://demowebshop.tricentis.com/addproducttocart/details/72/1",
        "Method=POST",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/build-your-cheap-own-computer",
        "Mode=HTTP",
        ITEMDATA,

        "Name=product_attribute_72_5_18",
        "Value=53",
        ENDITEM,

        "Name=product_attribute_72_6_19",
        "Value=54",
        ENDITEM,

        "Name=product_attribute_72_3_20",
        "Value=57",
        ENDITEM,

        "Name=addtocart_72.EnteredQuantity",
        "Value={Quantity}",
        ENDITEM,

        LAST);


    lr_end_transaction("4_addtocart", LR_AUTO);

    lr_think_time(5);

    lr_start_transaction("5_shoppingcart");


    web_url("cart",
        "URL=https://demowebshop.tricentis.com/cart",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/build-your-cheap-own-computer",
        "Mode=HTTP",
        LAST);


    lr_end_transaction("5_shoppingcart", LR_AUTO);

    lr_think_time(3);


    lr_start_transaction("6_checkout");


    web_url("getstatesbycountryid",
        "URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId={CountryId}&addEmptyStateIfRequired=true",
        "Resource=0",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/cart",
        "Mode=HTTP",
        LAST);


    web_submit_data("cart_checkout",
        "Action=https://demowebshop.tricentis.com/cart",
        "Method=POST",
        "EncType=multipart/form-data",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/cart",
        "Mode=HTTP",
        ITEMDATA,

        "Name=itemquantity{CartItemId}",
        "Value={Quantity}",
        ENDITEM,

        "Name=discountcouponcode",
        "Value=",
        ENDITEM,

        "Name=giftcardcouponcode",
        "Value=",
        ENDITEM,

        "Name=CountryId",
        "Value={CountryId}",
        ENDITEM,

        "Name=StateProvinceId",
        "Value={StateProvinceId}",
        ENDITEM,

        "Name=ZipPostalCode",
        "Value={ZipPostalCode}",
        ENDITEM,

        "Name=termsofservice",
        "Value=on",
        ENDITEM,

        "Name=checkout",
        "Value=checkout",
        ENDITEM,

        LAST);


    lr_end_transaction("6_checkout", LR_AUTO);

    lr_think_time(5);

    web_submit_data("OpcSaveBilling",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/",
        "Method=POST",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        "EncodeAtSign=YES",
        ITEMDATA,

        "Name=BillingNewAddress.Id",
        "Value=0",
        ENDITEM,

        "Name=BillingNewAddress.FirstName",
        "Value={FirstName}",
        ENDITEM,

        "Name=BillingNewAddress.LastName",
        "Value={LastName}",
        ENDITEM,

        "Name=BillingNewAddress.Email",
        "Value={Email}",
        ENDITEM,

        "Name=BillingNewAddress.Company",
        "Value=",
        ENDITEM,

        "Name=BillingNewAddress.CountryId",
        "Value=0",
        ENDITEM,

        "Name=BillingNewAddress.StateProvinceId",
        "Value=0",
        ENDITEM,

        "Name=BillingNewAddress.City",
        "Value=",
        ENDITEM,

        "Name=BillingNewAddress.Address1",
        "Value=",
        ENDITEM,

        "Name=BillingNewAddress.Address2",
        "Value=",
        ENDITEM,

        "Name=BillingNewAddress.ZipPostalCode",
        "Value=",
        ENDITEM,

        "Name=BillingNewAddress.PhoneNumber",
        "Value=",
        ENDITEM,

        "Name=BillingNewAddress.FaxNumber",
        "Value=",
        ENDITEM,

        LAST);


    lr_think_time(3);


    web_url("getstatesbycountryid_2",
        "URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId={CountryId}&addEmptyStateIfRequired=true",
        "Resource=0",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        LAST);


    lr_think_time(2);


    web_submit_data("OpcSaveBilling_2",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/",
        "Method=POST",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        "EncodeAtSign=YES",
        ITEMDATA,

        "Name=BillingNewAddress.Id",
        "Value=0",
        ENDITEM,

        "Name=BillingNewAddress.FirstName",
        "Value={FirstName}",
        ENDITEM,

        "Name=BillingNewAddress.LastName",
        "Value={LastName}",
        ENDITEM,

        "Name=BillingNewAddress.Email",
        "Value={Email}",
        ENDITEM,

        "Name=BillingNewAddress.Company",
        "Value={Company}",
        ENDITEM,

        "Name=BillingNewAddress.CountryId",
        "Value={CountryId}",
        ENDITEM,

        "Name=BillingNewAddress.StateProvinceId",
        "Value={StateProvinceId}",
        ENDITEM,

        "Name=BillingNewAddress.City",
        "Value={City}",
        ENDITEM,

        "Name=BillingNewAddress.Address1",
        "Value={Address1}",
        ENDITEM,

        "Name=BillingNewAddress.Address2",
        "Value=",
        ENDITEM,

        "Name=BillingNewAddress.ZipPostalCode",
        "Value={ZipPostalCode}",
        ENDITEM,

        "Name=BillingNewAddress.PhoneNumber",
        "Value={PhoneNumber}",
        ENDITEM,

        "Name=BillingNewAddress.FaxNumber",
        "Value=",
        ENDITEM,

        LAST);


    lr_think_time(3);

    web_submit_data("OpcSaveShipping",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/",
        "Method=POST",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        "EncodeAtSign=YES",
        ITEMDATA,

        "Name=shipping_address_id",
        "Value={ShippingAddressId}",
        ENDITEM,

        "Name=ShippingNewAddress.Id",
        "Value=0",
        ENDITEM,

        "Name=ShippingNewAddress.FirstName",
        "Value={FirstName}",
        ENDITEM,

        "Name=ShippingNewAddress.LastName",
        "Value={LastName}",
        ENDITEM,

        "Name=ShippingNewAddress.Email",
        "Value={Email}",
        ENDITEM,

        "Name=ShippingNewAddress.Company",
        "Value=",
        ENDITEM,

        "Name=ShippingNewAddress.CountryId",
        "Value={CountryId}",
        ENDITEM,

        "Name=ShippingNewAddress.StateProvinceId",
        "Value={StateProvinceId}",
        ENDITEM,

        "Name=ShippingNewAddress.City",
        "Value={City}",
        ENDITEM,

        "Name=ShippingNewAddress.Address1",
        "Value={Address1}",
        ENDITEM,

        "Name=ShippingNewAddress.Address2",
        "Value=",
        ENDITEM,

        "Name=ShippingNewAddress.ZipPostalCode",
        "Value={ZipPostalCode}",
        ENDITEM,

        "Name=ShippingNewAddress.PhoneNumber",
        "Value={PhoneNumber}",
        ENDITEM,

        "Name=ShippingNewAddress.FaxNumber",
        "Value=",
        ENDITEM,

        "Name=PickUpInStore",
        "Value=false",
        ENDITEM,

        LAST);


    lr_think_time(3);

    web_submit_data("OpcSaveShippingMethod",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/",
        "Method=POST",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        ITEMDATA,

        "Name=shippingoption",
        "Value={ShippingMethod}",
        ENDITEM,

        LAST);


    lr_think_time(3);

    web_submit_data("OpcSavePaymentMethod",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/",
        "Method=POST",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        ITEMDATA,

        "Name=paymentmethod",
        "Value={PaymentMethod}",
        ENDITEM,

        LAST);


    lr_think_time(3);

    lr_start_transaction("7_confirm");


    web_custom_request("OpcConfirmOrder",
        "URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/",
        "Method=POST",
        "Resource=0",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        "EncType=",
        LAST);


    web_url("completed",
        "URL=https://demowebshop.tricentis.com/checkout/completed/",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        LAST);


    lr_end_transaction("7_confirm", LR_AUTO);


    return 0;
}